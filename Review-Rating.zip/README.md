# Review Rating
 Mini Proj

pip install flask
pip install flask-cors
pip install scikit-learn
pip install nltk
pip install pandas
